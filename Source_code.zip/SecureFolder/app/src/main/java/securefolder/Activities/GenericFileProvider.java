package securefolder.Activities;

import android.support.v4.content.FileProvider;

/**
 * Used to give other apps access to sdcard content when files are tapped in the list view, see manifest file.
 */
public class GenericFileProvider extends FileProvider {

}
