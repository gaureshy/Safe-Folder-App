package securefolder.Activities.ui;

import android.os.Bundle;
import android.support.v7.preference.PreferenceFragmentCompat;

import securefolder.Activities.R;

import static securefolder.Activities.Settings.PREFERENCES_NAME;

public class SettingsFragment extends PreferenceFragmentCompat {
    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        getPreferenceManager().setSharedPreferencesName(PREFERENCES_NAME);
        setPreferencesFromResource(R.xml.preferences, rootKey);
    }
}
