package securefolder.Activities;

import android.content.Context;
import android.content.SharedPreferences;

import securefolder.Activities.models.ConcretePrivacyFile;
import securefolder.Activities.models.PrivifyFile;

public class Settings {
    public static final String PREFERENCES_NAME = "privacyAppSettings";

    static boolean isAutoLockEnabled(Context context) {
        return preferences(context).getBoolean("auto_lock_enabled", true);
    }

    private static SharedPreferences preferences(Context context) {
        return context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
    }
}
