package securefolder.Activities;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.Application;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import securefolder.Activities.ui.BaseActivity;
import securefolder.Activities.ui.PasswordActivity;

public class PrivacyApplication extends Application implements Application.ActivityLifecycleCallbacks {
    public static final String INTENT_LOCK_ACTION = BaseActivity.class.getName() + ".lock";

    private PendingIntent lockIntent;

    @Override
    public void onCreate() {
        super.onCreate();
        registerActivityLifecycleCallbacks(this);
        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                PasswordActivity.passphrase = null;
            }
        }, new IntentFilter(INTENT_LOCK_ACTION));
    }

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {

    }

    @Override
    public void onActivityStarted(Activity activity) {

    }

    @Override
    public void onActivityResumed(Activity activity) {
        cancelLock();
    }

    @Override
    public void onActivityPaused(Activity activity) {

    }

    @Override
    public void onActivityStopped(Activity activity) {

    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {

    }

    @Override
    public void onActivityDestroyed(Activity activity) {
        cancelLock();
    }



    private void cancelLock() {
        if (this.lockIntent == null) return;
        this.lockIntent.cancel();
        this.lockIntent = null;
    }
}
